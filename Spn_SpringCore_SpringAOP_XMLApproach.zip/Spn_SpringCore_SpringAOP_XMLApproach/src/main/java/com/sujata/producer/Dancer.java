package com.sujata.producer;

public class Dancer implements Performer {

	@Override
	public void perform() {
//		Audience audience=new Audience();
//		try{
//			audience.takeSeats();
//			audience.switchOffCellPhones();
//			
//			//Bussiness Need
			System.out.println("Dancer is dancing in Free Style!!!");
//			int x=10/0;
//			audience.applaud();
//		}
//		catch(Exception ex){
//			audience.demandRefund();
//		}
//		finally {
//			audience.leave();
//		}

	}

	
	
}
