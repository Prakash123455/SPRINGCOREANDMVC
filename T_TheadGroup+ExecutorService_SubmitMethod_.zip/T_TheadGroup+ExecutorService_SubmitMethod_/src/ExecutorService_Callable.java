import java.util.Scanner;
import java.util.concurrent.Callable;
import java.util.concurrent.ExecutionException;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.Future;

class Lab3Support implements Callable<String> {
	@Override
	public String call() throws Exception {
		System.out.println("In  thread " + Thread.currentThread().getName());
		return "hi";
	}
}

public class ExecutorService_Callable {

	public static void main(String[] args) {
		System.out.println("main - " + Thread.currentThread().getName());
		ExecutorService executorservice= Executors.newFixedThreadPool(5);
		Future f=executorservice.submit(new Lab3Support());
		executorservice.submit(new Lab3Support());
		executorservice.submit(new Lab3Support());
		executorservice.submit(new Lab3Support());
		executorservice.submit(new Lab3Support());
		try {
			System.out.println(f.get());
		} catch (InterruptedException | ExecutionException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}
}

////learn difference between submit and execute method
