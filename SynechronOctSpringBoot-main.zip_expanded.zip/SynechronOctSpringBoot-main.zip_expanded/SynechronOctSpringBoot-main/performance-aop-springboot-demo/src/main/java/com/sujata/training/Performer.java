package com.sujata.training;

public interface Performer {

	public void perform();
}
