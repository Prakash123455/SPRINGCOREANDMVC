package com.sujata.training;

public interface Instrument {

	public void play();
}
