package com.sujata.demo;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class FirstSpringbootdataJpaDemoApplicationTests {

	@Test
	void contextLoads() {
	}

}
