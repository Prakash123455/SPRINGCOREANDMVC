package com.sujata.training;

public interface Greet {

	public void wish(String name);
}
